package uk.ac.ed.inf;

import com.mapbox.geojson.FeatureCollection;

public interface Visualizer {

    FeatureCollection getFeatures();
}

[X] - Create Map class
[X] - Create ObstacleService
[X] Think about removing combined logger and instead loop over all loggers in drone class
[X] extract geometry methods from Map
[X] use points or coordinates everywhere
[X] fix issue with navigating boundaries
[X] fix issue when two readings are too close and no move would be needed
[X] remove dependency injection of objects which are only used to retrieve data
[ ] think about merging all the distance matrices and graphs into one
[ ] Make Map class Singleton
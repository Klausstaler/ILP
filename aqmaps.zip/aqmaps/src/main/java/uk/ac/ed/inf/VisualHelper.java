package uk.ac.ed.inf;

import com.mapbox.geojson.Feature;
import com.mapbox.geojson.FeatureCollection;
import com.mapbox.geojson.Point;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.LinearRing;
import uk.ac.ed.inf.backend.SensorService;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * If this file was committed, pls ignore, it's just for me to see!!
 */
public class VisualHelper {

    private List<Feature> features = new ArrayList<>();

    public VisualHelper(Map map, SensorService sensorService) throws IOException {
        Collection<Sensor> sensors = sensorService.getSensors();
        var shell = (LinearRing) map.getBoundary().getGeometryN(0);
        List<Geometry> obstacles = new ArrayList<>();
        for (int i = 0; i < map.getNumInteriorRing(); i++) {
            obstacles.add(map.getInteriorRingN(i));
        }

        List<List<Point>> newPlayArea = new ArrayList<>(
                new ArrayList<>());
        newPlayArea.add(this.geometryToPoints(shell));
        for (Geometry obstacle : obstacles)
            newPlayArea.add(this.geometryToPoints(obstacle));
        var area = com.mapbox.geojson.Polygon.fromLngLats(newPlayArea);
        features.add(Feature.fromGeometry(area));
        ///*
        for (Sensor sensor : sensors) {
            Point point = Point.fromLngLat(sensor.getX(),
                    sensor.getY());
            features.add(Feature.fromGeometry(point));
        }
        //*/

        FeatureCollection featureCollection = FeatureCollection.fromFeatures(features);
        new File("myviz.geojson").createNewFile();
        FileWriter writer = new FileWriter("myviz.geojson");

        String res = featureCollection.toJson();
        writer.write(res);
        writer.close();
    }

    private List<Point> geometryToPoints(Geometry ring) {
        Coordinate[] coordinates = ring.getCoordinates();
        List<Point> points = new ArrayList<>();
        for (Coordinate coordinate : coordinates) {
            points.add(Point.fromLngLat(coordinate.x, coordinate.y));
        }
        return points;
    }
}
